---
name: pdf-generator
description: Generate PDF files from markdown, HTML, or presentation formats. This skill should be used when creating PDFs, converting documentation to PDF, generating reports, or converting HTML presentations to printable PDF format.
---

# PDF Generator

## Overview

Generate high-quality PDF files from various source formats including markdown documents, HTML files, and web-based presentations. This skill provides workflows, scripts, and tools for converting content to professional PDF documents.

## Quick Start

To generate a PDF, identify the source format and use the appropriate conversion method:

**Markdown to PDF**: Use pandoc for document conversion
**HTML to PDF**: Use wkhtmltopdf for static HTML or Playwright for dynamic content
**Presentations**: Use specialized tools for reveal.js or similar frameworks

## Core Workflows

### Workflow 1: Converting Markdown to PDF

Use pandoc to convert markdown files to professionally formatted PDFs.

**Prerequisites:**
- pandoc installed (`winget install pandoc` or `choco install pandoc`)
- Optional: LaTeX distribution for advanced formatting

**Basic conversion:**
```bash
pandoc document.md -o document.pdf
```

**With custom options:**
```bash
pandoc document.md -o document.pdf \
  --variable geometry:margin=1in \
  --variable fontsize=12pt \
  --table-of-contents \
  --number-sections
```

**Using a template:**
```bash
pandoc document.md -o document.pdf \
  --template=.claude/skills/pdf-generator/assets/report-template.tex \
  --pdf-engine=xelatex
```

**Common use cases:**
- Technical documentation
- Reports with tables and charts
- Academic papers
- README files for distribution

### Workflow 2: Converting HTML to PDF

For static HTML files, use wkhtmltopdf for reliable conversion.

**Prerequisites:**
- wkhtmltopdf installed (`winget install wkhtmltopdf`)

**Basic conversion:**
```bash
wkhtmltopdf input.html output.pdf
```

**For web presentations (with styling):**
```bash
wkhtmltopdf --enable-local-file-access \
  --page-size A4 \
  --orientation Landscape \
  --print-media-type \
  --no-stop-slow-scripts \
  input.html output.pdf
```

**Common use cases:**
- HTML presentations
- Web pages for offline viewing
- Styled reports
- Interactive content preservation

### Workflow 3: Converting Presentations to PDF

For dynamic presentations with JavaScript (reveal.js, etc.), use Playwright or Puppeteer.

**Prerequisites:**
- Node.js and npm installed
- Playwright: `npm install -D playwright`

**Using the provided script:**
```bash
node .claude/skills/pdf-generator/scripts/html-to-pdf.js presentation.html presentation.pdf
```

**Manual approach with Playwright:**
See `scripts/html-to-pdf.js` for implementation details.

**Common use cases:**
- Reveal.js presentations
- Slide decks
- Interactive presentations
- Training materials

### Workflow 4: Batch Conversion

Convert multiple files in a directory.

**Batch markdown to PDF:**
```bash
for file in *.md; do
  pandoc "$file" -o "${file%.md}.pdf"
done
```

**PowerShell batch conversion:**
```powershell
Get-ChildItem -Filter *.md | ForEach-Object {
  pandoc $_.FullName -o ($_.BaseName + ".pdf")
}
```

## Tool Decision Tree

```
What format is your source?

  Markdown (.md)
    Use pandoc (Workflow 1)

  Static HTML (.html)
    Simple page?
      Use wkhtmltopdf (Workflow 2)
    Presentation with animations?
       Use Playwright script (Workflow 3)

  Multiple files?
    Use batch conversion (Workflow 4)

  Custom requirements?
     Check references/pandoc-options.md
```

## Best Practices

### Quality Guidelines

1. **Validate inputs**: Always check source files exist before conversion
2. **Check dependencies**: Verify required tools are installed
3. **Preserve formatting**: Use appropriate engines for content type
4. **Test output**: Verify generated PDFs render correctly
5. **Handle errors**: Provide clear messages if conversion fails

### Performance Tips

1. **Compress images** before conversion to reduce PDF size
2. **Use appropriate PDF engines** (wkhtmltopdf for HTML, xelatex for complex layouts)
3. **Batch process** multiple files when possible
4. **Cache dependencies** for repeated conversions

### Common Pitfalls

- **Broken images**: Ensure image paths are absolute or relative to the source file
- **Missing fonts**: Install required fonts system-wide before conversion
- **Large file size**: Compress images or use PDF compression tools after generation
- **Lost styling**: Use `--print-media-type` flag for wkhtmltopdf to preserve CSS

## Troubleshooting

**"pandoc: command not found"**
- Install pandoc: `winget install pandoc`

**"wkhtmltopdf: command not found"**
- Install wkhtmltopdf: `winget install wkhtmltopdf`

**Images not showing in PDF**
- Use absolute paths for images
- Ensure images are in accessible locations
- Check file permissions

**Fonts not rendering**
- Install fonts system-wide (Windows Fonts folder)
- Use `--pdf-engine=xelatex` for better font support

**PDF too large**
- Compress images before conversion
- Use lower resolution for images
- Apply PDF compression after generation

**JavaScript not executing**
- Use Playwright script for dynamic content
- Ensure `--no-stop-slow-scripts` flag with wkhtmltopdf
- Allow sufficient page load time

For detailed pandoc options, see `references/pandoc-options.md`.

## Resources

This skill includes:

### scripts/
- `html-to-pdf.js`: Node.js script using Playwright for HTML to PDF conversion
- `convert-presentation.ps1`: PowerShell script for batch presentation conversion

### references/
- `pandoc-options.md`: Comprehensive guide to pandoc command-line options
- `troubleshooting.md`: Extended troubleshooting guide with solutions

### assets/
- `report-template.tex`: LaTeX template for professional reports
- `css/pdf-styles.css`: CSS styles optimized for PDF output

## Examples

### Example 1: Documentation to PDF
```bash
# Convert project README to PDF with table of contents
pandoc README.md -o documentation.pdf \
  --toc \
  --toc-depth=2 \
  --number-sections \
  --variable geometry:margin=1.5in
```

### Example 2: Presentation to PDF
```bash
# Convert reveal.js presentation to PDF
node .claude/skills/pdf-generator/scripts/html-to-pdf.js \
  presentation.html \
  presentation-slides.pdf
```

### Example 3: Report with Custom Template
```bash
# Generate report using custom template
pandoc report.md -o report.pdf \
  --template=.claude/skills/pdf-generator/assets/report-template.tex \
  --pdf-engine=xelatex \
  --variable author="Your Name" \
  --variable date="\today"
```
